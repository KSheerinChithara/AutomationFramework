package pagemethods;

import java.util.Set;

import org.openqa.selenium.WebDriver;

public class homepagementhods {
	
	 WebDriver driver = null;
	

	
	
	public static void  clickMenu(WebDriver driver)  {
		  pageobjects.homepageobjects.menuIcon(driver).click();
		 	
	}
	
	public static void  clickMenFashion(WebDriver driver)  {
		  pageobjects.homepageobjects.chooseMenFashion(driver).click();
		 	
	}
	
	public static void  clickFormalShoes(WebDriver driver)  {
		  pageobjects.homepageobjects.chooseFormalShoes(driver).click();
		 	
	}
	
	public static void filterCentrino(WebDriver driver) throws InterruptedException  {
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.selectCentrino(driver));
		  pageobjects.homepageobjects.selectCentrino(driver).click();

	}
	
	public static void chooseItem1(WebDriver driver) throws InterruptedException  {
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.selectItem1(driver));

		  pageobjects.homepageobjects.selectItem1(driver).click(); 
		  String winHandleBefore = driver.getWindowHandle();
		  for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
		  }
		  Thread.sleep(2000);
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.selectSize(driver));
		  pageobjects.homepageobjects.select9UKSize(driver).click();
		  Thread.sleep(3000);
		  helper.Utilities.scrollByTop(driver);
		  pageobjects.homepageobjects.cartAddButton(driver).click();
		  Thread.sleep(3000);
		  driver.close();
		  driver.switchTo().window(winHandleBefore);
		  helper.Utilities.scrollByTop(driver);

		 	
	}
	
	public static void chooseItem3(WebDriver driver) throws InterruptedException  {
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.selectItem1(driver));

		  pageobjects.homepageobjects.selectItem3(driver).click();
		  String winHandleBefore = driver.getWindowHandle();
		  for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
		  }
		  Thread.sleep(3000);
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.select9UKSize(driver));
          pageobjects.homepageobjects.select9UKSize(driver).click();
          Thread.sleep(3000);
		  helper.Utilities.scrollByTop(driver);
		  pageobjects.homepageobjects.cartAddButton(driver).click();
		  driver.close();
		  driver.switchTo().window(winHandleBefore);
		  helper.Utilities.scrollByTop(driver);


		 	
	}
	public static void chooseItem2(WebDriver driver) throws InterruptedException  {
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.selectItem1(driver));

		pageobjects.homepageobjects.selectItem2(driver).click();
		  String winHandleBefore = driver.getWindowHandle();
		  for(String winHandle : driver.getWindowHandles()){
			    driver.switchTo().window(winHandle);
		  }
		  Thread.sleep(3000);
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.select9UKSize(driver));
        pageobjects.homepageobjects.select9UKSize(driver).click();
        Thread.sleep(3000);
		  helper.Utilities.scrollByTop(driver);
		  pageobjects.homepageobjects.cartAddButton(driver).click();
		  driver.close();
		  driver.switchTo().window(winHandleBefore);
		  helper.Utilities.scrollByTop(driver);


		 	
	}
	
	public static void clickCartIcon(WebDriver driver) throws InterruptedException  {
		  Thread.sleep(4000);
		  pageobjects.homepageobjects.cartIcon(driver).click();
		  

		 	
	}
	
	public static void checkAmount(WebDriver driver) throws InterruptedException  {
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.subTotal(driver));
		  String Value =pageobjects.homepageobjects.subTotal(driver).getText();
		  System.out.println(Value);
		  String value1 = Value.replaceAll(",", "");
		  System.out.println(value1);
		  int i=Integer.parseInt(value1);  
		  if(i>2000)
		  {
			  System.out.println("delete item");
			  Thread.sleep(4000);
			  helper.Utilities.scrollByTop(driver);
          	  pageobjects.homepageobjects.deleteItem(driver).click();
  	  
		  }

		 	
	
		  
		 
		 	
	}
	
	
	
	
	
	
}
