package testcases;

import org.testng.annotations.Test;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class homepage extends baseclass{
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
 
  @Test(priority = 1, enabled = true)
  public void checkingCartValue() throws InterruptedException {
	  
	  pagemethods.homepagementhods.clickMenu(driver);
	  pagemethods.homepagementhods.clickMenFashion(driver);
	  pagemethods.homepagementhods.clickFormalShoes(driver);
	  pagemethods.homepagementhods.filterCentrino(driver);
	  pagemethods.homepagementhods.chooseItem1(driver);
	  pagemethods.homepagementhods.chooseItem2(driver);
	  pagemethods.homepagementhods.chooseItem3(driver);
	  pagemethods.homepagementhods.clickCartIcon(driver); 
	  pagemethods.homepagementhods.checkAmount(driver);
	  
}
}