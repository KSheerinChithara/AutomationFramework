package helper;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Utilities {
	
	 WebDriver driver = null;

	//to scroll bottom of page
	 static public void scrollByBottomOfPage(WebDriver driver) {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,document.body.scrollHeight)");				
}
	 static public void scrollByTillObject(WebDriver driver, WebElement webElement) {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("arguments[0].scrollIntoView();", webElement);
		 }
	 
	 static public void scrollByTop(WebDriver driver) {
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,250)");
		 }
	 }
