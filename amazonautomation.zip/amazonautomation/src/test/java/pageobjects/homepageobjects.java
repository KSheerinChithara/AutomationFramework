package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class homepageobjects {

	WebDriver driver = null;

	public static WebElement menuIcon(WebDriver driver) {
		return driver.findElement(By.xpath("//a[@id='nav-hamburger-menu']"));

	}
	
	public static WebElement chooseMenFashion(WebDriver driver) {
		return driver.findElement(By.xpath("//div[normalize-space()=\"Men's Fashion\"]"));

	}
	
	public static WebElement chooseFormalShoes(WebDriver driver) {
		return driver.findElement(By.xpath("//a[normalize-space()='Formal Shoes']"));

	}
	
	public static WebElement selectBata(WebDriver driver) {
		return driver.findElement(By.xpath("//li[@id='p_89/BATA']//i[@class='a-icon a-icon-checkbox']"));

	}
	
	public static WebElement selectCentrino(WebDriver driver) {
		return driver.findElement(By.xpath("//div[5]//ul[1]//li[2]//span[1]//a[1]//div[1]//label[1]//i[1]"));

	}
	
	
	
	public static WebElement cartAddButton(WebDriver driver) {
		return driver.findElement(By.xpath("//input[@id='add-to-cart-button']"));
	
	}
	
	public static WebElement cartIcon(WebDriver driver) {
		return driver.findElement(By.xpath("//span[@id='nav-cart-count']"));
	
	}
	
	public static WebElement selectItem1(WebDriver driver) {
		return driver.findElement(By.xpath("//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1']//img[1]"));
	
	}
	
	public static WebElement selectItem2(WebDriver driver) {
		return driver.findElement(By.xpath("//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_2']//img[1]"));
	
	}
	
	public static WebElement selectItem3(WebDriver driver) {
		return driver.findElement(By.xpath("//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_4']//img[1]"));
	
	}
	//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_2']//img[1]
	//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_2']//img[1]
	//div[@class='s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_2']//img[1]
	public static WebElement select9UKSize(WebDriver driver) {
		return driver.findElement(By.xpath("//span[@id='size_name_3']//input[@name='3']"));

	}
	
	public static WebElement selectSize(WebDriver driver) {
		return driver.findElement(By.xpath("//span[@class='a-size-small']"));

	}
	
	public static WebElement subTotal(WebDriver driver) {
		return driver.findElement(By.xpath("//span[@id='sc-subtotal-amount-activecart']//span//span[@class='a-price-whole']"));

	}
//	public static WebElement subTotal(WebDriver driver) {
//		return driver.findElement(By.xpath("//span[@id='sc-subtotal-amount-buybox']//span//span[@class='a-price-whole']"));
//
//	}

	
	public static WebElement deleteItem(WebDriver driver) {
		return driver.findElement(By.cssSelector("input[value='Delete']"));

	}
	
	
}
