package pagemethods;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import testcases.baseclass;

public class homepagementhods {
	
	 WebDriver driver = null;
	
	public static void enterFilterLG(WebDriver driver) throws InterruptedException  {
		  
		  pageobjects.homepageobjects.seachBar(driver).click();
		  pageobjects.homepageobjects.seachBar(driver). sendKeys("ig soundbar");
		  pageobjects.homepageobjects.searchIcon(driver).click();  
		  helper.Utilities.scrollByTillObject(driver, pageobjects.homepageobjects.itemLG(driver));
		  Thread.sleep(3000);
		  pageobjects.homepageobjects.itemLG(driver).click();	
		  pageobjects.homepageobjects.lgItem(driver).click();
		  Set<String> allwindow = driver.getWindowHandles();  
		  for(String newWindow : allwindow)
		  {
			  driver.switchTo().window(newWindow);
		  }
		  pageobjects.homepageobjects.cart(driver).click();
		  pageobjects.homepageobjects.skipButton(driver).click();
		  pageobjects.homepageobjects.checkOut(driver).click();


}
}
