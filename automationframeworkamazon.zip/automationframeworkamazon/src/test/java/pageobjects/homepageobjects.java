package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class homepageobjects {

	WebDriver driver = null;

	public static WebElement seachBar(WebDriver driver) {
		return driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));

	}
	
	public static WebElement searchIcon(WebDriver driver) {
		return driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));

	}
	
	public static WebElement itemLG(WebDriver driver) {
		return driver.findElement(By.xpath("//li[@id='p_89/LG']//i[@class='a-icon a-icon-checkbox']"));

	}
	
	public static WebElement checkItem(WebDriver driver) {
		return driver.findElement(By.xpath("//span[normalize-space()='LG 165.1 cm (65 inches) 4K Ultra HD Smart OLED TV 65A1PTZ (Dark Meteo Titan) (2021 Model)']"));

	}
	public static WebElement lgItem(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[3]/div[2]/div[3]/div/div/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span"));
	}
	
	public static WebElement cart(WebDriver driver) {
		return driver.findElement(By.xpath("//input[@id='add-to-cart-button']"));
	
	}
	
	public static WebElement skipButton(WebDriver driver) {
		return driver.findElement(By.xpath("//input[@aria-labelledby='attachSiNoCoverage-announce']"));
	
	}
	
	public static WebElement checkOut(WebDriver driver) {
		return driver.findElement(By.xpath("//input[@name='proceedToRetailCheckout']"));
	
	}
	
}
