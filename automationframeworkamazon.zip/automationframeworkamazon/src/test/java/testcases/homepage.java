package testcases;

import org.testng.annotations.Test;

import static org.testng.Assert.assertNotNull;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class homepage extends baseclass{
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
 
  @Test(priority = 1, enabled = true)
  public void checkingFilterLG() throws InterruptedException {
	  
           pagemethods.homepagementhods.enterFilterLG(driver);
          
           
}
}