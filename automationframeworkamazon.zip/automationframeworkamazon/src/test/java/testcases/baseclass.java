package testcases;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.touch.ScrollAction;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import pageobjects.*;

public class baseclass {
	
	WebDriver driver = new ChromeDriver();

	
	@BeforeSuite
	public void bforesuite() {
		
		System.setProperty("webdriver.chrome.driver", "chromedriver");
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
		
	}
	
 @Test
 public void openingPage() {
	 System.out.println("amazon page opened");
	 
	 }
 
 
 @org.testng.annotations.AfterSuite
 public void AfterSuite() {
	 
	 driver.quit();
 }
 
 

}
