package pageobjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class contactpage {

	WebDriver driver = null;

	public static WebElement firstName(WebDriver driver) {
		return driver.findElement(By.id("firstname-b15d4232-7672-429d-81fd-a00020bddf95"));

	}
	
	public static WebElement lastName(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"lastname-b15d4232-7672-429d-81fd-a00020bddf95\"]"));

	}
	
	public static WebElement emailID(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"email-b15d4232-7672-429d-81fd-a00020bddf95\"]"));

	}
	
	public static WebElement phoneNumber(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"mobilephone-b15d4232-7672-429d-81fd-a00020bddf95\"]"));

	}
	public static WebElement howKnowAboutsUs(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"how_did_you_hear_about_us_-b15d4232-7672-429d-81fd-a00020bddf95\"]"));
	}
	
	
	
	public static WebElement messageBox(WebDriver driver) {
		return driver.findElement(By.xpath("//textarea[@id='message-b15d4232-7672-429d-81fd-a00020bddf95']"));
	
	}
	
	public static WebElement sumbitButton(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"hsForm_b15d4232-7672-429d-81fd-a00020bddf95\"]/div/div[2]/input"));
	
	}
	
	public static WebElement chooseLinkedIn(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"how_did_you_hear_about_us_-b15d4232-7672-429d-81fd-a00020bddf95\"]/option[9]"));
	
	}
	
	public static WebElement chooseExciting(WebDriver driver) {
		return driver.findElement(By.xpath("//span[normalize-space()='Exciting']"));
	
	}
	
	public static WebElement thankMessage(WebDriver driver) {
		return driver.findElement(By.xpath("//p[contains(text(),\"Thank you for your message. We'll get back to you \")]"));
	
	}
	
	
}
