package pagemethods;

import java.util.Set;

import org.openqa.selenium.WebDriver;
import testcases.baseTest;

public class contactpagemethods {
	
	 WebDriver driver = null;
	
	public static void enterFirstName(WebDriver driver, String firstname)  {
		  pageobjects.contactpage.firstName(driver).click();
		  pageobjects.contactpage.firstName(driver).sendKeys(firstname);
		
	}
	
	public static void enteSecondName(WebDriver driver, String lastname)  {
		  pageobjects.contactpage.lastName(driver).click();
		  pageobjects.contactpage.lastName(driver).sendKeys(lastname);
		
	}
	
	public static void enterMailID(WebDriver driver, String mailid)  {
		  pageobjects.contactpage.emailID(driver).click();
		  pageobjects.contactpage.emailID(driver).sendKeys(mailid);
		
	}
	
	public static void enterPhoneNumber(WebDriver driver, String phonenumber)  {
		  pageobjects.contactpage.phoneNumber(driver).click();
		  pageobjects.contactpage.phoneNumber(driver).sendKeys(phonenumber);
		
	}
	public static void clickHowYouKnow(WebDriver driver)  {
		  pageobjects.contactpage.howKnowAboutsUs(driver).click();
		 
		
	}
	
	public static void chooselinkedon(WebDriver driver)  {
		  pageobjects.contactpage.chooseLinkedIn(driver).click();
		 
		
	}
	
	public static void enterMessage(WebDriver driver, String message)  {
		  pageobjects.contactpage.messageBox(driver).click();
		  pageobjects.contactpage.messageBox(driver).sendKeys(message);
		
	}
	
	public static void clickSubmitButton(WebDriver driver)  {
		  pageobjects.contactpage.sumbitButton(driver).click();
		  pageobjects.contactpage.sumbitButton(driver).sendKeys("sheerin");
		
	}
	
	
	
	

}

