package testcases;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.annotations.Test;

import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class contactPageTest extends baseTest{
	
	
	JavascriptExecutor js = (JavascriptExecutor) driver;
 
  @Test(priority = 1, enabled = true)
  public  void submittingContactUs() throws InterruptedException {
	  
           helper.Utilities.scrollByTillObject(driver, pageobjects.contactpage.chooseExciting(driver));
           
           Thread.sleep(3000);

           pagemethods.contactpagemethods.enterFirstName(driver, "name1");
           
           pagemethods.contactpagemethods.enteSecondName(driver, "name2");
           
           pagemethods.contactpagemethods.enterMailID(driver, "123@gmail.com");
           
           pagemethods.contactpagemethods.enterPhoneNumber(driver, "71234567890");
           
           pagemethods.contactpagemethods.enterMessage(driver, "I am interersted,Please contact me");
           
           pagemethods.contactpagemethods.clickHowYouKnow(driver);
          
           pagemethods.contactpagemethods.chooselinkedon(driver);

           pagemethods.contactpagemethods.clickSubmitButton(driver);
           
           AssertJUnit.assertTrue(pageobjects.contactpage.thankMessage(driver).isDisplayed());
                                 
  }
}